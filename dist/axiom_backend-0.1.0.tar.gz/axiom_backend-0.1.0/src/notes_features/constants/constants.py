DATABASE_NAME =  "axiom_db"
NOTE_COLLECTION = "notes"
QUIZ_COLLECTION = "quizzes"
FLASHCARD_COLLECTION = "flashcard_decks"